﻿Imports System.Data.SqlClient

Public Class userverify
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from userverify where pin='" & TextBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader()
        If d1.HasRows Then
            MsgBox("Verified")
        Else
            MsgBox("Incorrect Pin")
            TextBox1.Text = ""
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
    End Sub
End Class