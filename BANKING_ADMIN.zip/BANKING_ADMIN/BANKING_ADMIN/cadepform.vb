﻿Imports System.Data.SqlClient

Public Class cadepform
    Dim pkvar As String
    Dim RandGen As New Random
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        newbut()
    End Sub
    Sub newbut()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.Text = ""
        TextBox5.Text = ""
        TextBox4.Text = RandGen.Next(0, 100).ToString
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        saverecord()
    End Sub
    Sub saverecord()
       If TextBox1.Text = "" Then
            MsgBox("Please enter the amount")
            Exit Sub
        End If
       
        If TextBox4.Text = "" Then
            MsgBox("Please enter the voucher number")
            Exit Sub
        End If
        If ComboBox1.Text = "" Then
            MsgBox("Please select the Current account number")
            Exit Sub
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from cadepentry where [Voucher No]='" & TextBox4.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            MsgBox("Record is already present")
            Exit Sub
        End If
        Dim q1var, q2var As String
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        q1var = "insert into cadepentry("
        q2var = "values("
        q1var = q1var & "[Voucher No]" & ","
        q2var = q2var & "'" & TextBox4.Text & "',"
        q1var = q1var & "Date" & ","
        q2var = q2var & "'" & DateTimePicker1.Text & "',"
        q1var = q1var & "[Ca A/c No]" & ","
        q2var = q2var & "'" & ComboBox1.Text & "',"
        q1var = q1var & "Amount" & ","
        q2var = q2var & "'" & TextBox1.Text & "',"
        q1var = q1var & "Details" & ","
        q2var = q2var & "'" & TextBox2.Text & "',"
        q1var = q1var & "Remark" & ")"
        q2var = q2var & "'" & TextBox3.Text & "')"
        MsgBox(q1var & q2var)
        Dim cmd1 As New SqlCommand(q1var & q2var, conn)
        cmd1.ExecuteNonQuery()
        MsgBox("Data Saved")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.Text = ""
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
        newbut()

    End Sub


    Private Sub cadepform_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        disrecord()
        TextBox5.Enabled = False
        Me.WindowState = FormWindowState.Maximized
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("Select Caccno From Ccustentry order by Caccno", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        While d1.Read()
            ComboBox1.Items.Add(d1(0).ToString)
        End While
        TextBox4.Text = RandGen.Next(0, 100).ToString
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If vbNo = MsgBox("Are you sure , you want to update this ?", MsgBoxStyle.YesNo, "Update") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from cadepentry where [Voucher No]='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        saverecord()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If vbNo = MsgBox("Are you sure , you want to delete this ?", MsgBoxStyle.YesNo, "Delete") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from cadepentry where [Voucher No]='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        disrecord()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        pkvar = DataGridView1.CurrentRow.Cells(0).Value
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from cadepentry where [Voucher No]='" & pkvar & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            d1.Read()
            TextBox4.Text = d1(0).ToString
            DateTimePicker1.Text = d1(1).ToString
            'ComboBox1.Text = d1(2).ToString
            TextBox1.Text = d1(3).ToString
            TextBox2.Text = d1(4).ToString
            TextBox3.Text = d1(5).ToString

        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            ComboBox1.Text = ""
        End If
    End Sub
    Sub disrecord()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim ds1 As New DataSet
        Dim adp As New SqlDataAdapter("Select * from cadepentry order by [Voucher No]", conn)
        adp.Fill(ds1)
        DataGridView1.DataSource = ds1.Tables(0)
        If conn.State = ConnectionState.Open Then conn.Close()
    End Sub

    Private Sub ComboBox1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.LostFocus
        Dim t1, t2 As Double
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim Cmd0 As New SqlCommand("select sum(Amount) from cadepentry where [Ca A/c No]='" & ComboBox1.Text & "'", conn)
        Dim D1 As SqlDataReader = Cmd0.ExecuteReader()
        If D1.HasRows Then
            D1.Read()
            t1 = IIf(IsDBNull(D1(0)), 0, D1(0))
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim Cmd1 As New SqlCommand("select sum(Amount) from cawithdrawentry where [Current A/c No]='" & ComboBox1.Text & "'", conn)
        Dim D2 As SqlDataReader = Cmd1.ExecuteReader()
        If D2.HasRows Then
            D2.Read()
            t2 = IIf(IsDBNull(D2(0)), 0, D2(0))
        End If
        TextBox5.Text = "₹" & t1 - t2
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select Caccno from Ccustentry where Caccno='" & ComboBox1.Text & "'", conn)

        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            d1.Read()
            ComboBox1.Text = d1(0).ToString
        End If
    End Sub

    
End Class