﻿Imports System.Data.SqlClient
Imports System.Net.Mail
'Dim sms As String = "http://bulksms.mysmsmantra.com:8080/WebSMS/SMSAPI.jsp?username=Project3113&password=360637197&sendername=Infopr&mobileno=8310155125&message=The dustbin is almost full please check"

Public Class LoginForm1
    
    Dim RandGen As New Random
    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.
    
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from userlogin where username='" & UsernameTextBox.Text & "' and password='" & PasswordTextBox.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader()
        If d1.HasRows Then
            MsgBox("User Id and Password verified!!")

            uname = UsernameTextBox.Text
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            Dim cmd1 As New SqlCommand("update userlogin set otp='" & TextBox1.Text & "' where username='" & UsernameTextBox.Text & "'", conn)
            cmd1.ExecuteNonQuery()
            If conn.State = ConnectionState.Open Then conn.Close()
            TextBox1.AppendText(" (OTP)" + vbNewLine)
            TextBox1.AppendText("------------------------------------" + vbNewLine)
            TextBox1.AppendText("Welcome To Maze Bank" + vbNewLine)
            TextBox1.AppendText("------------------------------------" + vbNewLine)
            TextBox1.AppendText("Your OTP is " + TextBox1.Text + vbNewLine)
            TextBox1.AppendText("------------------------------------" + vbNewLine)
            TextBox1.AppendText("Please login with these credentials" + vbNewLine)
            TextBox1.AppendText("------------------------------------" + vbNewLine)

            Dim Mail As New MailMessage
            Mail.Subject = "Registration Successful"
            If TextBox1.Text = "" Then
                MsgBox("Please enter email address", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
            End If
            Mail.To.Add("likiraghu18@gmail.com")
            Mail.To.Add("seervilalith2202@gmail.com")
            Mail.From = New MailAddress("bankmaze23@gmail.com")
            Mail.Body = TextBox1.Text

            Dim SMTP As New SmtpClient("smtp.gmail.com")
            SMTP.EnableSsl = True
            SMTP.Credentials = New System.Net.NetworkCredential("bankmaze23@gmail.com", "mwzxeezawbybkyfm")
            SMTP.Port = "587"
            SMTP.Send(Mail)
            MsgBox("An otp has been sent on your mail id", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Banking")
            otp.Show()
        Else
            MsgBox("Invalid Login")
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        TextBox1.Hide()
        TextBox1.Text = RandGen.Next(1000, 10000).ToString
        UsernameTextBox.Text = ""
        PasswordTextBox.Text = ""
        dat.Text = Date.Now.ToString("dd/MMM/yyyy")
    End Sub

    Private Sub Label1_Click(sender As System.Object, e As System.EventArgs) Handles Label1.Click
        Dim Mail As New MailMessage
        Dim email As String
        Dim password As String
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from  userlogin where username='" & UsernameTextBox.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader()
        If d1.HasRows Then
            d1.Read()
            email = d1(3).ToString
            password = d1(1).ToString
            Mail.Subject = "MAZE BANK"
            Mail.To.Add(email)
            Mail.From = New MailAddress("bankmaze23@gmail.com")
            Mail.Body = ("Password : " + password + vbNewLine)
            Dim SMTP As New SmtpClient("smtp.gmail.com")
            SMTP.EnableSsl = True
            SMTP.Credentials = New System.Net.NetworkCredential("bankmaze23@gmail.com", "mwzxeezawbybkyfm")
            SMTP.Port = "587"
            SMTP.Send(Mail)
            MsgBox("Check your email")
        Else
            MsgBox("invalid login")
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        time.Text = TimeOfDay
    End Sub
End Class
