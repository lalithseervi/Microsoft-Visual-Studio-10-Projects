﻿Imports System.Data.SqlClient

Module Module1
    Public conn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=E:\BANKING_ADMIN\BANKING_ADMIN\BANKING_ADMIN\BANKING_ADMIN\BANKING_ADMIN\bin\Debug\logindb.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
    Public pkvar, uname As String
    Public Regex As Object
End Module
