﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIParent1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDIParent1))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SavingBankToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SavingBankAcTypesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SBCustomerEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AmountDepositToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AmountWithdrawToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentAccountTypesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CACustomerEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CADepositEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CAWithdrawEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SBReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SBCustomerListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SBDepositListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SbWithdrawListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CAReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CADepositListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CAWithdrawListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckBalanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SavingsAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentAccountToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.time = New System.Windows.Forms.Label()
        Me.dat = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.SavingBankToolStripMenuItem, Me.CurrentAccountToolStripMenuItem, Me.SBReportsToolStripMenuItem, Me.CAReportsToolStripMenuItem, Me.CheckBalanceToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(9, 3, 0, 3)
        Me.MenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip.Size = New System.Drawing.Size(1893, 38)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(84, 32)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'SavingBankToolStripMenuItem
        '
        Me.SavingBankToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.SavingBankToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SavingBankAcTypesToolStripMenuItem, Me.SBCustomerEntryToolStripMenuItem, Me.AmountDepositToolStripMenuItem, Me.AmountWithdrawToolStripMenuItem})
        Me.SavingBankToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SavingBankToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.SavingBankToolStripMenuItem.Name = "SavingBankToolStripMenuItem"
        Me.SavingBankToolStripMenuItem.Size = New System.Drawing.Size(203, 32)
        Me.SavingBankToolStripMenuItem.Text = "Savings Account"
        '
        'SavingBankAcTypesToolStripMenuItem
        '
        Me.SavingBankAcTypesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SavingBankAcTypesToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SavingBankAcTypesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SavingBankAcTypesToolStripMenuItem.Name = "SavingBankAcTypesToolStripMenuItem"
        Me.SavingBankAcTypesToolStripMenuItem.Size = New System.Drawing.Size(338, 32)
        Me.SavingBankAcTypesToolStripMenuItem.Text = "Saving Bank A/c Types"
        '
        'SBCustomerEntryToolStripMenuItem
        '
        Me.SBCustomerEntryToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SBCustomerEntryToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SBCustomerEntryToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SBCustomerEntryToolStripMenuItem.Name = "SBCustomerEntryToolStripMenuItem"
        Me.SBCustomerEntryToolStripMenuItem.Size = New System.Drawing.Size(338, 32)
        Me.SBCustomerEntryToolStripMenuItem.Text = "SB Customer Entry"
        '
        'AmountDepositToolStripMenuItem
        '
        Me.AmountDepositToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.AmountDepositToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmountDepositToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AmountDepositToolStripMenuItem.Name = "AmountDepositToolStripMenuItem"
        Me.AmountDepositToolStripMenuItem.Size = New System.Drawing.Size(338, 32)
        Me.AmountDepositToolStripMenuItem.Text = "Amount Deposit"
        '
        'AmountWithdrawToolStripMenuItem
        '
        Me.AmountWithdrawToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.AmountWithdrawToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmountWithdrawToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AmountWithdrawToolStripMenuItem.Name = "AmountWithdrawToolStripMenuItem"
        Me.AmountWithdrawToolStripMenuItem.Size = New System.Drawing.Size(338, 32)
        Me.AmountWithdrawToolStripMenuItem.Text = "Amount Withdraw"
        '
        'CurrentAccountToolStripMenuItem
        '
        Me.CurrentAccountToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.CurrentAccountToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CurrentAccountTypesToolStripMenuItem, Me.CACustomerEntryToolStripMenuItem, Me.CADepositEntryToolStripMenuItem, Me.CAWithdrawEntryToolStripMenuItem})
        Me.CurrentAccountToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CurrentAccountToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.CurrentAccountToolStripMenuItem.Name = "CurrentAccountToolStripMenuItem"
        Me.CurrentAccountToolStripMenuItem.Size = New System.Drawing.Size(203, 32)
        Me.CurrentAccountToolStripMenuItem.Text = "Current Account"
        '
        'CurrentAccountTypesToolStripMenuItem
        '
        Me.CurrentAccountTypesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CurrentAccountTypesToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CurrentAccountTypesToolStripMenuItem.Name = "CurrentAccountTypesToolStripMenuItem"
        Me.CurrentAccountTypesToolStripMenuItem.Size = New System.Drawing.Size(333, 32)
        Me.CurrentAccountTypesToolStripMenuItem.Text = "Current Account Types"
        '
        'CACustomerEntryToolStripMenuItem
        '
        Me.CACustomerEntryToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CACustomerEntryToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CACustomerEntryToolStripMenuItem.Name = "CACustomerEntryToolStripMenuItem"
        Me.CACustomerEntryToolStripMenuItem.Size = New System.Drawing.Size(333, 32)
        Me.CACustomerEntryToolStripMenuItem.Text = "CA Customer Entry"
        '
        'CADepositEntryToolStripMenuItem
        '
        Me.CADepositEntryToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CADepositEntryToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CADepositEntryToolStripMenuItem.Name = "CADepositEntryToolStripMenuItem"
        Me.CADepositEntryToolStripMenuItem.Size = New System.Drawing.Size(333, 32)
        Me.CADepositEntryToolStripMenuItem.Text = "CA Deposit Entry"
        '
        'CAWithdrawEntryToolStripMenuItem
        '
        Me.CAWithdrawEntryToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CAWithdrawEntryToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CAWithdrawEntryToolStripMenuItem.Name = "CAWithdrawEntryToolStripMenuItem"
        Me.CAWithdrawEntryToolStripMenuItem.Size = New System.Drawing.Size(333, 32)
        Me.CAWithdrawEntryToolStripMenuItem.Text = "CA Withdraw Entry"
        '
        'SBReportsToolStripMenuItem
        '
        Me.SBReportsToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.SBReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SBCustomerListToolStripMenuItem, Me.SBDepositListToolStripMenuItem, Me.SbWithdrawListToolStripMenuItem})
        Me.SBReportsToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SBReportsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.SBReportsToolStripMenuItem.Name = "SBReportsToolStripMenuItem"
        Me.SBReportsToolStripMenuItem.Size = New System.Drawing.Size(140, 32)
        Me.SBReportsToolStripMenuItem.Text = "SB Reports"
        '
        'SBCustomerListToolStripMenuItem
        '
        Me.SBCustomerListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SBCustomerListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SBCustomerListToolStripMenuItem.Name = "SBCustomerListToolStripMenuItem"
        Me.SBCustomerListToolStripMenuItem.Size = New System.Drawing.Size(271, 32)
        Me.SBCustomerListToolStripMenuItem.Text = "SB Customer List"
        '
        'SBDepositListToolStripMenuItem
        '
        Me.SBDepositListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SBDepositListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SBDepositListToolStripMenuItem.Name = "SBDepositListToolStripMenuItem"
        Me.SBDepositListToolStripMenuItem.Size = New System.Drawing.Size(271, 32)
        Me.SBDepositListToolStripMenuItem.Text = "SB Deposit List"
        '
        'SbWithdrawListToolStripMenuItem
        '
        Me.SbWithdrawListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SbWithdrawListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SbWithdrawListToolStripMenuItem.Name = "SbWithdrawListToolStripMenuItem"
        Me.SbWithdrawListToolStripMenuItem.Size = New System.Drawing.Size(271, 32)
        Me.SbWithdrawListToolStripMenuItem.Text = "Sb Withdraw List"
        '
        'CAReportsToolStripMenuItem
        '
        Me.CAReportsToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.CAReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerListToolStripMenuItem, Me.CADepositListToolStripMenuItem, Me.CAWithdrawListToolStripMenuItem})
        Me.CAReportsToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CAReportsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.CAReportsToolStripMenuItem.Name = "CAReportsToolStripMenuItem"
        Me.CAReportsToolStripMenuItem.Size = New System.Drawing.Size(148, 32)
        Me.CAReportsToolStripMenuItem.Text = "CA Reports"
        '
        'CustomerListToolStripMenuItem
        '
        Me.CustomerListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CustomerListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerListToolStripMenuItem.Name = "CustomerListToolStripMenuItem"
        Me.CustomerListToolStripMenuItem.Size = New System.Drawing.Size(281, 32)
        Me.CustomerListToolStripMenuItem.Text = "Customer List"
        '
        'CADepositListToolStripMenuItem
        '
        Me.CADepositListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CADepositListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CADepositListToolStripMenuItem.Name = "CADepositListToolStripMenuItem"
        Me.CADepositListToolStripMenuItem.Size = New System.Drawing.Size(281, 32)
        Me.CADepositListToolStripMenuItem.Text = "CA Deposit List"
        '
        'CAWithdrawListToolStripMenuItem
        '
        Me.CAWithdrawListToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CAWithdrawListToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CAWithdrawListToolStripMenuItem.Name = "CAWithdrawListToolStripMenuItem"
        Me.CAWithdrawListToolStripMenuItem.Size = New System.Drawing.Size(281, 32)
        Me.CAWithdrawListToolStripMenuItem.Text = "CA Withdraw List"
        '
        'CheckBalanceToolStripMenuItem
        '
        Me.CheckBalanceToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.CheckBalanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SavingsAccountToolStripMenuItem, Me.CurrentAccountToolStripMenuItem1})
        Me.CheckBalanceToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBalanceToolStripMenuItem.Name = "CheckBalanceToolStripMenuItem"
        Me.CheckBalanceToolStripMenuItem.Size = New System.Drawing.Size(180, 32)
        Me.CheckBalanceToolStripMenuItem.Text = "Check Balance"
        '
        'SavingsAccountToolStripMenuItem
        '
        Me.SavingsAccountToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.SavingsAccountToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SavingsAccountToolStripMenuItem.Name = "SavingsAccountToolStripMenuItem"
        Me.SavingsAccountToolStripMenuItem.Size = New System.Drawing.Size(263, 32)
        Me.SavingsAccountToolStripMenuItem.Text = "Savings Account"
        '
        'CurrentAccountToolStripMenuItem1
        '
        Me.CurrentAccountToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.CurrentAccountToolStripMenuItem1.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CurrentAccountToolStripMenuItem1.Name = "CurrentAccountToolStripMenuItem1"
        Me.CurrentAccountToolStripMenuItem1.Size = New System.Drawing.Size(263, 32)
        Me.CurrentAccountToolStripMenuItem1.Text = "Current Account"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(100, 32)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 1023)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Padding = New System.Windows.Forms.Padding(2, 0, 21, 0)
        Me.StatusStrip.Size = New System.Drawing.Size(1893, 27)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(57, 22)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'time
        '
        Me.time.BackColor = System.Drawing.Color.Transparent
        Me.time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.time.Font = New System.Drawing.Font("Book Antiqua", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time.ForeColor = System.Drawing.Color.Black
        Me.time.Location = New System.Drawing.Point(1723, 919)
        Me.time.Name = "time"
        Me.time.Size = New System.Drawing.Size(170, 39)
        Me.time.TabIndex = 9
        Me.time.Text = "00:00:00"
        Me.time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dat
        '
        Me.dat.BackColor = System.Drawing.Color.Transparent
        Me.dat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dat.Font = New System.Drawing.Font("Book Antiqua", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dat.ForeColor = System.Drawing.SystemColors.Desktop
        Me.dat.Location = New System.Drawing.Point(12, 919)
        Me.dat.Name = "dat"
        Me.dat.Size = New System.Drawing.Size(170, 39)
        Me.dat.TabIndex = 10
        Me.dat.Text = "00/00/0000"
        Me.dat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'MDIParent1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1893, 1050)
        Me.Controls.Add(Me.dat)
        Me.Controls.Add(Me.time)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.StatusStrip)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "MDIParent1"
        Me.Text = "BANKING ADMINISTRATION"
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents SavingBankToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SavingBankAcTypesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SBCustomerEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AmountDepositToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AmountWithdrawToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentAccountTypesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CACustomerEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CADepositEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CAWithdrawEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SBReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SBCustomerListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SBDepositListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SbWithdrawListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CAReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CADepositListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CAWithdrawListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBalanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SavingsAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentAccountToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents time As System.Windows.Forms.Label
    Friend WithEvents dat As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
